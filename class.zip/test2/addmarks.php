<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?>




<?php
include ("connection.php");
$branch=$_GET['branchsel'];
$year=$_GET['yearsel'];
$sub=$_GET['sub'];
$exam=$_GET['exam'];
$stdsel=$_GET['stdsel'];
$marko=$_GET['marko'];

$qu="Select studentid from studentlogin where Full_Name='".$stdsel."'";
$re=mysql_query($qu) or die("Query failed...".mysql_error());
while($row=mysql_fetch_array($re))
			{
				$stdid=$row[0];
			}
if($exam=='Midterm 1')
	{$val = mysql_query("select 1 from marks_".$branch."_".$year."_".$sub);

		if($val== FALSE)
		{
		$query="CREATE TABLE marks_".$branch."_".$year."_".$sub."(student_id varchar(30), midterm1 int, midterm2 int, sem int)";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		}
	$ini=0;
	$query2="INSERT INTO marks_".$branch."_".$year."_".$sub." VALUES('".$stdid."',".$marko.",".$ini.",".$ini.")";
	$res2=mysql_query($query2) or die("Query failed...".mysql_error());
	}
	
else if($exam=='Midterm 2')
{
	$query2="Update marks_".$branch."_".$year."_".$sub." set midterm2=".$marko." where student_id='".$stdid."'";
	$res2=mysql_query($query2) or die("Query failed...".mysql_error());
}

else if($exam=='Semester')
{
	$query2="Update marks_".$branch."_".$year."_".$sub." set sem=".$marko." where student_id='".$stdid."'";
	$res2=mysql_query($query2) or die("Query failed...".mysql_error());
}



if($res2==1)
{
	echo "<h3>Marks Upload...</h3>
          <p><form name='addm' action='performance.php'>
		  <table>
			<tr>
				<td><label>Subject</label></td>
				<td><select name='sub' value=".$sub."'>
					
					<option>EDC</option>
					<option>CPP</option>
					<option>Maths</option>
				</select></td>
			</tr>	
			<tr>
				<td><label>Exam</label></td>
				<td><select name='exam' value=".$exam."'>
					
					
					<option>Midterm 1</option>
					<option>Midterm 2</option>
					<option>Semester</option>
				</select></td>
			</tr>
			<tr>
				<td><label>Student Name</label></td>";
	
			
							echo "<input type='text' name='branchsel' value='".$branch."' style='display:none;'><input type='text' name='yearsel' value='".$year."' style='display:none;'>";
							
							$query="SELECT Full_Name from studentlogin where Branch='".$branch."' AND Year='".$year."'";
							$res=mysql_query($query) or die("Query failed...".mysql_error());
							echo "<td><select name='stdsel'>";
							while($row=mysql_fetch_array($res))
							{
								echo "<option>".$row[0]."</option>";
			
							}
							echo "</select></td>";
							echo "</p>
		  </tr>
		  <tr>
		 
		  <td><label>Marks Obtained</label></td>
		  <td><input type='number' name='marko'></td>
		  </tr>
		  
		  </table>
		  <input type='submit' value='Submit' name='addmm'>
		  </form>";
				
}
	
?>

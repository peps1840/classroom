<?php



session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

include ("connection.php");
			
$lyr=$_GET['lyr'];
$lyr=$lyr+1;
			$query2="INSERT INTO year values(".$lyr.")";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			if($res2==1)
			{	header('location:year.php');
				echo "successfully uploaded";
			}
			
			else
				echo "Error!";
				
?>
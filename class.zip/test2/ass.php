<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?>


<!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>HACKSLASH</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/css/prettyPhoto.css" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/quicksand.js"></script>
<script type="text/javascript" src="style/js/portfolio.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
<script type="text/javascript" src="style/js/jquery.prettyPhoto.js"></script>
</head>
<body>
<div id="container"> 
  <!-- Begin Header Wrapper -->
  <div id="page-top">
    <div id="header-wrapper"> 
      <!-- Begin Header -->
      <div id="header">
        
        <!-- Logo --> 
        <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html" class="selected">COLLEGE MANAGEMENT SYSTEM</a>
               
              </li>
             
        <!-- End Menu -->
      </div>
      <!-- End Header --> 
    </div>
  </div>
  <!-- End Header Wrapper --> 
   <!-- Begin Slider -->
 
  <!-- End Slider -->
  
  <!-- Begin Wrapper -->
  <div id="wrapper">
    <div id="portfolio"> 
	<br> <br> <br> <br>
	<br> <br>
      <!-- Begin Portfolio Navigation -->
      
      <!-- End Portfolio Navigation --> 
      
      <!-- Begin Portfolio Elements -->
      <ul id="gallery" class="grid">
        
        <!-- Begin Image 1 -->
       
       <h1><center>Assignment
	   </h1>
	   
		
		
		<input type="submit" name="view" value="view"  onClick="view()";>
		<div id="view" style="display:none;">
		
			
		<?php
		  include ("connection.php");
		  
		  $query="SELECT subject,topic,date FROM ass";
		  $res=mysql_query($query) or die("Query failed...".mysql_error());
		  echo "<table><tr><th>Subject</th><th>Topic</th><th>Date</th></tr>";
		  while($row=mysql_fetch_array($res))
			{
				echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
			
			}
		  echo "</table>";
		  ?>
			</div>
			
			
			
			<input type="submit" name="add" value="upload assignment"  onClick="show()";><br><br>
		<div id="add" style="display:none;">
	  <form name="notice" action="ass1.php" method="post">
			<table>
				<tr>
					<td><label>Subject</label></td>
					<td><input type="text" name="subject"></td>
				</tr>
				<tr>
					<td><label>Topic</label></td>
					<td><input type="text" name="topic"></td>
				</tr>
				<tr>
					<td><label>Date</label></td>
					<td><input type="date" name="date"></td>
				</tr>
			</table>
			<input type="file"  name="file"><br><br>
			<input type="submit" value="upload" name="imp">
		</form>
	</div>
	   
	   
		</center>

        
      </ul>
      <!-- End Portfolio Elements --> 
      
    </div>
  </div>
  
  <!-- End Wrapper -->
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->


<!-- End Footer --> 
<script type="text/javascript">
$(document).ready(function(){
			$("#gallery a[rel^='prettyPhoto']").prettyPhoto({theme:'light_square',autoplay_slideshow: false});
			
			$("ul.grid img").hide()
			$("ul.grid img").each(function(i) {
			  $(this).delay(i * 200).fadeIn();
			});
			
});

function view()
{
	
	document.getElementById("view").style="display:inline;";
}

function show()
{
	
	document.getElementById("add").style="display:inline;";
}


</script>
</body>
</html>

		
	   <?php
	   
	   
	   
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
			
			$subject=$_POST['subject'];
			$topic=$_POST['topic'];
			$da=$_POST['date'];
			$query2="INSERT INTO ass values('".$subject."','".$topic."','".$da."')";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			if($res2==1)
			{
				echo "successfully uploaded";
				header('location:ass.php');
			}
			
			
		 
		  ?>
	   
	    
	
	
 <?php
include ("connection.php");


session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');



if(isset($_GET['p']))
{	$studid=$_GET['studid'];
	echo $studid;
	$query="SELECT sub1 from student_att where student_id='".$studid."'";
	$res=mysql_query($query) or die("Query failed...".mysql_error());
	
	$row=mysql_fetch_array($res);
	$sub=$row[0];
	$sub++;
			
	$query2="SELECT totsub from student_att where student_id='".$studid."'";
	$res2=mysql_query($query2) or die("Query failed...".mysql_error());
		 
		 $row=mysql_fetch_array($res2);
				$totsub=$row[0];
			
				$totsub++;
			
	$query3="Update student_att set sub1='".$sub."' where student_id='".$studid."'";
	$query4="Update student_att set totsub='".$totsub."' where student_id='".$studid."'";
	$res3=mysql_query($query3) or die("Query failed...".mysql_error());
	$res4=mysql_query($query4) or die("Query failed...".mysql_error());
	if($res3==1 && $res4==1)
		{
			echo "hi!";
		}
	
	
}
	
else
	{

	$query2="SELECT totsub from student_att where student_id='".$studid."'";
	$res2=mysql_query($query2) or die("Query failed...".mysql_error());
		 
		  $row=mysql_fetch_array($res2);
		  
				$totsub=$row[0];
				$totsub++;
		  
	$query3="Update student_att set totsub='".$totsub."' where student_id='".$studid."'";
	$res3=mysql_query($query3) or die("Query failed...".mysql_error());
	if($res3==1)
		{
			header('location:faculty.html');
		}
	
	
	}

			

?>

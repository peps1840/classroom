-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 26, 2017 at 10:25 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `classroom`
--

-- --------------------------------------------------------

--
-- Table structure for table `acclogin`
--

CREATE TABLE IF NOT EXISTS `acclogin` (
  `id` int(11) NOT NULL,
  `accid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adminnotice`
--

CREATE TABLE IF NOT EXISTS `adminnotice` (
  `notice` varchar(200) NOT NULL,
  `details` varchar(500) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminnotice`
--

INSERT INTO `adminnotice` (`notice`, `details`, `date`) VALUES
('ibm meeting on 20 dec', '', '2019-02-17'),
('today is holiday 25 dec', '', '2025-12-17'),
('ji', 'hjkjkljolk', '2012-03-17'),
('sjhdkj', 'dhskjckjzxckxz', '2012-04-17'),
('cdjclk', 'kdjckjdscklmkdsck', '2012-03-17'),
('heudik', 'jdkediljo', '0000-00-00'),
('', '', '0000-00-00'),
('dedsf', 'sdf', '2012-03-17'),
('', '', '0000-00-00'),
('dedsf', 'sdf', '2012-03-17'),
('dedsf', 'sdf', '2012-03-17'),
('dedsf', 'sdf', '2012-03-17'),
('IBM LEAVE', 'HOLIDAY FOR ALL STUDENTS FOR ONE WEEK', '2017-03-23'),
('hhh', '', '2017-03-10'),
('', '', '2017-03-07'),
('', '', '2017-03-14');

-- --------------------------------------------------------

--
-- Table structure for table `ass`
--

CREATE TABLE IF NOT EXISTS `ass` (
  `subject` varchar(50) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `branch`
--

CREATE TABLE IF NOT EXISTS `branch` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `hod` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `branch`
--

INSERT INTO `branch` (`id`, `name`, `hod`) VALUES
(12, 'dddd', 'bbb'),
(12345, 'cs', 'adbbb'),
(111, 'it', 'sxc');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE IF NOT EXISTS `class` (
  `name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`name`) VALUES
('abc'),
('abc'),
('abcp'),
(''),
('ddd'),
(''),
(''),
('asss'),
('dcvdx'),
(''),
('gggg'),
('nckjadf'),
('abbb'),
(''),
('abbb'),
('ffgg'),
(''),
(''),
(''),
(''),
(''),
(''),
(''),
(''),
(''),
(''),
(''),
('');

-- --------------------------------------------------------

--
-- Table structure for table `fac`
--

CREATE TABLE IF NOT EXISTS `fac` (
  `name` varchar(50) NOT NULL,
  `id` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fac`
--

INSERT INTO `fac` (`name`, `id`) VALUES
('vv', '123');

-- --------------------------------------------------------

--
-- Table structure for table `facultylogin`
--

CREATE TABLE IF NOT EXISTS `facultylogin` (
  `id` int(11) NOT NULL,
  `facultyid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `facultylogin`
--

INSERT INTO `facultylogin` (`id`, `facultyid`, `password`) VALUES
(1, 'faculty123', 'fac');

-- --------------------------------------------------------

--
-- Table structure for table `hodlogin`
--

CREATE TABLE IF NOT EXISTS `hodlogin` (
  `id` int(11) NOT NULL,
  `hodid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hodlogin`
--

INSERT INTO `hodlogin` (`id`, `hodid`, `password`) VALUES
(1, 'hod123', 'hod');

-- --------------------------------------------------------

--
-- Table structure for table `impq`
--

CREATE TABLE IF NOT EXISTS `impq` (
  `subject` varchar(50) NOT NULL,
  `topic` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `que` varchar(500) NOT NULL,
  `branch` varchar(50) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `impq`
--

INSERT INTO `impq` (`subject`, `topic`, `date`, `que`, `branch`, `year`) VALUES
('', '', '2017-03-06', '', '', 0),
('xsxc', 'mmm', '2017-03-15', '', '', 0),
('bbb', 'vvv', '0000-00-00', '', 'cs', 0),
('hiii', 'helo', '0004-05-05', '', 'cs', 0),
('hey ', 'test', '2013-02-17', '', '', 0),
('hey ', 'test', '2013-02-17', '', '', 0),
('dwqds', 'asd', '0000-00-00', 'upload', 'dddd', 0),
('dwqds', 'asd', '0000-00-00', 'upload', 'dddd', 0),
('dwqds', 'asd', '0000-00-00', 'upload', 'dddd', 0),
('dwqds', 'asd', '0000-00-00', 'upload', 'dddd', 0),
('jsljlskal', 'lisjdlks;l', '2012-03-17', 'upload', 'cs', 0),
('jsljlskal', 'lisjdlks;l', '2012-03-17', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dsdd', 'sdsad', '0000-00-00', 'upload', 'cs', 0),
('dszfd', 'dffdsf', '2012-03-17', 'upload', '', 0),
('sad', 'sdsad', '2012-03-17', 'upload', '', 0),
('ffff', 'ffff', '2017-03-07', 'upload', 'dddd', 0),
('ffff', 'ffff', '2017-03-07', 'upload', 'dddd', 0),
('ffff', 'ffff', '2017-03-07', 'upload', 'dddd', 0),
('nnn', 'nnnn', '2017-03-07', 'mmmmm', 'dddd', 0);

-- --------------------------------------------------------

--
-- Table structure for table `library`
--

CREATE TABLE IF NOT EXISTS `library` (
  `book` varchar(100) NOT NULL,
  `bookid` varchar(20) NOT NULL,
  `author` varchar(50) NOT NULL,
  `price` int(100) NOT NULL,
  `qty` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `library`
--

INSERT INTO `library` (`book`, `bookid`, `author`, `price`, `qty`) VALUES
('dksjkl', '22232', 'mdfkdjk', 122, 1);

-- --------------------------------------------------------

--
-- Table structure for table `librarylogin`
--

CREATE TABLE IF NOT EXISTS `librarylogin` (
  `id` int(11) NOT NULL,
  `liblogin` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `marks_dddd_1_edc`
--

CREATE TABLE IF NOT EXISTS `marks_dddd_1_edc` (
  `student_id` varchar(30) DEFAULT NULL,
  `midterm1` int(11) DEFAULT NULL,
  `midterm2` int(11) DEFAULT NULL,
  `sem` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `marks_dddd_1_edc`
--

INSERT INTO `marks_dddd_1_edc` (`student_id`, `midterm1`, `midterm2`, `sem`) VALUES
('', 122, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `parentlogin`
--

CREATE TABLE IF NOT EXISTS `parentlogin` (
  `id` int(11) NOT NULL,
  `parid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE IF NOT EXISTS `profile` (
  `name` varchar(50) NOT NULL,
  `qualification` varchar(50) NOT NULL,
  `address` varchar(50) NOT NULL,
  `salary` int(50) NOT NULL,
  `aadhar` varchar(50) NOT NULL,
  `pan` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`name`, `qualification`, `address`, `salary`, `aadhar`, `pan`) VALUES
('cds', 'cxc', 'dsf', 3, 'fffffffd', 'ffff'),
('cdc', 'czxc', '111', 122, 'opijkol', 'ghjg'),
('', 'cdc', '', 0, '', ''),
('rohit', 'php', 'qwee', 455, 'fdg', 'gfgf');

-- --------------------------------------------------------

--
-- Table structure for table `sadminlogin`
--

CREATE TABLE IF NOT EXISTS `sadminlogin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sadminid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `sadminlogin`
--

INSERT INTO `sadminlogin` (`id`, `sadminid`, `password`) VALUES
(1, 'dean123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `studentc`
--

CREATE TABLE IF NOT EXISTS `studentc` (
  `name` varchar(50) NOT NULL,
  `id` varchar(50) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentc`
--

INSERT INTO `studentc` (`name`, `id`, `branch`, `year`) VALUES
('vggf', '123', '', 0),
('deds', '12', '', 0),
('dddd', '123', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `studentlogin`
--

CREATE TABLE IF NOT EXISTS `studentlogin` (
  `studentid` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `Full_Name` varchar(100) NOT NULL,
  `Branch` varchar(30) NOT NULL,
  `Year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student_att`
--

CREATE TABLE IF NOT EXISTS `student_att` (
  `student_id` varchar(200) NOT NULL,
  `sub1` int(200) NOT NULL,
  `totsub` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

CREATE TABLE IF NOT EXISTS `subject` (
  `subject` varchar(30) NOT NULL,
  `branch` varchar(30) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `subjectc`
--

CREATE TABLE IF NOT EXISTS `subjectc` (
  `subject` varchar(30) NOT NULL,
  `faculty` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subjectc`
--

INSERT INTO `subjectc` (`subject`, `faculty`) VALUES
('ppl', 'sunil sir'),
('bb', 'bbb');

-- --------------------------------------------------------

--
-- Table structure for table `tt_cs_2`
--

CREATE TABLE IF NOT EXISTS `tt_cs_2` (
  `day` varchar(30) DEFAULT NULL,
  `tsub1` varchar(30) DEFAULT NULL,
  `tsub2` varchar(30) DEFAULT NULL,
  `tsub3` varchar(30) DEFAULT NULL,
  `tsub4` varchar(30) DEFAULT NULL,
  `tsub5` varchar(30) DEFAULT NULL,
  `tsub6` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tt_cs_2`
--

INSERT INTO `tt_cs_2` (`day`, `tsub1`, `tsub2`, `tsub3`, `tsub4`, `tsub5`, `tsub6`) VALUES
('Monday', 'dsd', '', '', '', '', ''),
('Tuesday', 'dsa', '', '', '', '', ''),
('Wednesday', 'asd', '', '', '', '', ''),
('Thursday', 'asd', '', '', '', '', ''),
('Friday', 'sda', '', '', '', '', ''),
('Saturday', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tt_it_1`
--

CREATE TABLE IF NOT EXISTS `tt_it_1` (
  `day` varchar(30) NOT NULL,
  `tsub1` varchar(30) NOT NULL,
  `tsub2` varchar(30) NOT NULL,
  `tsub3` varchar(30) NOT NULL,
  `tsub4` varchar(30) NOT NULL,
  `tsub5` varchar(30) NOT NULL,
  `tsub6` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `year`
--

CREATE TABLE IF NOT EXISTS `year` (
  `yr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `year`
--

INSERT INTO `year` (`yr`) VALUES
(1),
(2),
(3),
(4);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

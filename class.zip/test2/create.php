

		
	   <?php
	   
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
		  
		  $bname=$_GET["bname"];
			$bid=$_GET["bid"];
			$authname=$_GET["authname"];
			$price=$_GET["price"];
			$qty=$_GET["qty"];
			
			
			
			
			$query="insert into library values('".$bname."','".$bid."','".$authname."',".$price.",".$qty.")";
				$res=mysql_query($query);
				if($res==1)
				{
					echo "Book Record added Succesfully!";
					header('location:view.php');
				}
				else
					{
						echo "Error! Please enter the details again";
					header('location:create.html');
					}
			
				
			
			
		 
		  ?>
	   
	    
	
	

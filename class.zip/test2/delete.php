  <?php
  
		
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		include ("connection.php");
		$bid=$_GET["bid"];

		$query="delete from library where bookid='".$bid."'";
		$res=mysql_query($query);
		if($res==1)
		{	echo "Book Record Deleted Succesfully!";
			header('location:lib.html');
			}
		else
		  {echo "Error! Please enter the details again";
		   header('location:delete.html');
		   }
		?>

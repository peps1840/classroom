
		
	   <?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
			
			$fname=$_POST['fname'];
			
			$id=$_POST['fid'];
			$query2="INSERT INTO fac values('".$fname."',".$id.")";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			if($res2==1)
			{
				echo "successfully uploaded";
				header('location:fac.php');
			}
			
			
		 
		  ?>
	   
	    
	
	
<?php
include "connection.php";

if(isset($_POST['register']))
{
	$uname=$_POST['uname'];
	$mobile=$_POST['tel'];

	if($_FILES['pic']!="")
	{
		move_uploaded_file($_FILES['pic']['tmp_name'],"uploads/".$uname.".jpg");
		$file="uploads/".$uname.".jpg";
	}

	else
	{
		echo "Upload Failed...";
	}

	$sql="INSERT INTO pbook(user,tel,img) VALUES('".$uname."','".$mobile."','".$file."')";
	$res=mysql_query($sql) or die("Query Failed...".mysql_error());

	if($res)
	{
		echo "Records Inserted Successfully...";
	}
	else
	{
		echo "Records Not inserted";
	}

	mysql_close($con);
}
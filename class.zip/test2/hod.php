<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?><!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>HACKSLASH</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/css/prettyPhoto.css" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/quicksand.js"></script>
<script type="text/javascript" src="style/js/portfolio.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
<script type="text/javascript" src="style/js/jquery.prettyPhoto.js"></script>
</head>
<body>
<div id="container"> 
  <!-- Begin Header Wrapper -->
  <div id="page-top">
    <div id="header-wrapper"> 
      <!-- Begin Header -->
      <div id="header">
        
        <!-- Logo --> 
        <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html" class="selected">COLLEGE MANAGEMENT SYSTEM</a>
               <li><img src="style/images/result.png" alt="" /> Logout</li>
              </li>
             
        <!-- End Menu -->
      </div>
      <!-- End Header --> 
    </div>
  </div>
  <!-- End Header Wrapper --> 
   <!-- Begin Slider -->
 
  <!-- End Slider -->
  
  <!-- Begin Wrapper -->
  <div id="wrapper">
    <div id="portfolio"> 
	<br> <br> <br> <br>
	<br> <br>
      <!-- Begin Portfolio Navigation -->
      
      <!-- End Portfolio Navigation --> 
      
      <!-- Begin Portfolio Elements -->
      <ul id="gallery" class="grid">
        
        <!-- Begin Image 1 -->
        <li data-id="id-1" class="photography"> <a href="notice.php" > <img src="style/images/art/t2.jpeg" alt="" /></a> </li>
        
        
        <li data-id="id-2" class="illustration"> <a href="timetable.php" title=""> <img src="style/images/art/add.jpeg" alt="" /></a> </li>
        <li data-id="id-3" class="video"> <a href="marks.php" title=""> <img src="style/images/art/mar.jpeg" alt="" /></a> </li>
		<li data-id="id-5" class="web"> <a href="trackd.php" title=""> <img src="style/images/art/track.jpeg" alt="" /></a> </li>
       
		<li data-id="id-5" class="web"> <a href="branch.php" title=""> <img src="style/images/art/t5.jpeg" alt="" /></a> </li>
      
        <li data-id="id-7" class="web"> <a href="profile.php"> <img src="style/images/art/t7.jpeg" alt="" /></a> </li>
		<li data-id="id-6" class="web"> <a href="trackd1.php"  title=""> <img src="style/images/art/view.jpeg" alt="" /> </a> </li>

        <li data-id="id-5" class="web"> <a href="branchf.php" title=""> <img src="style/images/art/h1.jpeg" alt="" /></a> </li>
      </ul>
      <!-- End Portfolio Elements --> 
      
    </div>
  </div>
  
  <!-- End Wrapper -->
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->


<!-- End Footer --> 
<script type="text/javascript">
$(document).ready(function(){
			$("#gallery a[rel^='prettyPhoto']").prettyPhoto({theme:'light_square',autoplay_slideshow: false});
			
			$("ul.grid img").hide()
			$("ul.grid img").each(function(i) {
			  $(this).delay(i * 200).fadeIn();
			});
			
});
</script>
</body>
</html>
<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?><!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>HACKSLASH</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/css/prettyPhoto.css" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/quicksand.js"></script>
<script type="text/javascript" src="style/js/portfolio.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
<script type="text/javascript" src="style/js/jquery.prettyPhoto.js"></script>
</head>
<body>
<div id="container"> 
  <!-- Begin Header Wrapper -->
  <div id="page-top">
    <div id="header-wrapper"> 
      <!-- Begin Header -->
      <div id="header">
        
        <!-- Logo --> 
        <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html" class="selected">COLLEGE MANAGEMENT SYSTEM</a>
               
              </li>
             
        <!-- End Menu -->
      </div>
      <!-- End Header --> 
    </div>
  </div>
  <!-- End Header Wrapper --> 
   <!-- Begin Slider -->
 
  <!-- End Slider -->
  
  <!-- Begin Wrapper -->
  <div id="wrapper">
    <div id="portfolio"> 
	<br> <br> <br> <br>
	<br> <br>
      <!-- Begin Portfolio Navigation -->
      
      <!-- End Portfolio Navigation --> 
      
      <!-- Begin Portfolio Elements -->
      <ul id="gallery" class="grid">
        
        <!-- Begin Image 1 -->
        
        
       
		<?php
		  include ("connection.php");
		  
		  $query="SELECT name,hod,id FROM branch";
		  $res=mysql_query($query) or die("Query failed...".mysql_error());
		   echo "<center><h1>HOD</h1>";
		  while($row=mysql_fetch_array($res))
			{
				
				echo "<a href='profilet.php'>".$row[0]."</a><br>";
			
			}
			
		  ?>
		  
		</center>
        

        
      </ul>
      <!-- End Portfolio Elements --> 
      
    </div>
  </div>
  
  <!-- End Wrapper -->
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->


<!-- End Footer --> 
<script type="text/javascript">
$(document).ready(function(){
			$("#gallery a[rel^='prettyPhoto']").prettyPhoto({theme:'light_square',autoplay_slideshow: false});
			
			$("ul.grid img").hide()
			$("ul.grid img").each(function(i) {
			  $(this).delay(i * 200).fadeIn();
			});
			
});

function view()
{
	
	document.getElementById("addbranch").style="display:inline;";
}
</script>
</body>
</html>
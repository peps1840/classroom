<?php
include("connection.php");
if(isset($_GET['submit']))
{
	$id=$_GET["userName"];
	$pass=$_GET["passWord"];
	$des=$_GET["role"];

if($des=="dean")
	{
	
		$query="SELECT * FROM sadminlogin where sadminid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['sadminid'];
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:dean.php');
			}
		}
		
		
	}
	
	else if($des=="hod")
	{
	
		$query="SELECT * FROM hodlogin where hodid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['hodid'];
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:hod.php');
			}
		}
		
		
	}
	
	else if($des=="faculty")
	{
	
		$query="SELECT * FROM facultylogin where facultyid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['facultyid'];
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:faculty.php');
			}
		}
		
		
	}
	
	else if($des=="student")
	{
	
		$query="SELECT * FROM studentlogin where studentid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:student.php');
			}
		}
		
		
	}
	
	
	
	else if($des=="library")
	{
	
		$query="SELECT * FROM librarylogin where libid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['libid'];
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:lib.php');
			}
		}
		
		
	}
	
	else if($des=="parent")
	{
	
		$query="SELECT * FROM parentlogin where parid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['parid'];
			session_start();
			$_SESSION['logged_in']=$id;
			header('location:parents.php');
			}
		}
		
		
	}
	else
		echo "Invalid username or password input.Please try again...";
}
?> 
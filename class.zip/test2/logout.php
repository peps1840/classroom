<?php
session_start();
session_destroy();
$_SESSION['logged_in']="";
header('location:index.html');
?>

		
	   <?php
	   
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
			
			$notice=$_POST['notice'];
			$details=$_POST['deatils'];
			$da=$_POST['date'];
			$query2="INSERT INTO adminnotice values('".$notice."','".$details."','".$da."')";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			if($res2==1)
			{
				echo "successfully uploaded";
				header('location:notice.php');
			}
			
			
		 
		  ?>
	   
	    
	
	
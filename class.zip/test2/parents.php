<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?><!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>HACKSLASH</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/jquery.cycle.all.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
<script type="text/javascript">
$(function() {
			if ($('#sliderholder-cycle').length) {
			// timeouts per slide (in seconds) 
			var timeouts = [150,390,25]; 
			function calculateTimeout(currElement, nextElement, opts, isForward) { 
			    var index = opts.currSlide; 
			    return timeouts[index] * 1000;
			}
			jQuery('#sliderholder-cycle').cycle({
				fx: 'fade',
				pager: '.slidernav',
				prev:    '.sliderprev',
        		next:    '.slidernext',
				speed: 1000,
				timeoutFn: calculateTimeout,
				pagerEvent: 'click',
    			pauseOnPagerHover: true,
    			cleartype: 1
});
			jQuery('#sliderholder-cycle').css("display", "block");
			jQuery('.slidernav').css("display", "block");
			
			}
}); 
</script>
</head>
<body>
<div id="container"> 
  <!-- Begin Header Wrapper -->
  <div id="page-top">
    <div id="header-wrapper"> 
      <!-- Begin Header -->
      
          <div id="header">
        
        <!-- Logo --> 
        <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html" class="selected">COLLEGE MANAGEMENT SYSTEM</a>
                <li><a href="index.html"><img src="style/images/result.png" alt="" />Logout</li></a> 
              </li>
              
              
        <!-- End Menu --> 
      </div>
      <!-- End Header --> 
    </div>
  </div>
        
  <!-- End Header Wrapper --> 
  
  <!-- Begin Slider -->
  <div id="cycle-wrapper">
    <div id="sliderholder-cycle"> <img src="style/images/art/123.jpeg" width="960" height="380" />
     
      <img src="style/images/p6.png" width="960" height="380" /> </div>
    <ul class="slidernav">
    </ul>
    <div class="sliderdir"> <a href="#"><span class="sliderprev">Prev</span></a> <a href="#"><span class="slidernext">Next</span></a> </div>
  </div>
  <!-- End Slider -->
  
  <!-- Begin Wrapper -->
  <div id="wrapper"> 
    
    <!-- Begin Intro -->
    <div class="intro">
      
    </div>
    <!-- End Intro --> 
    
    <!-- Begin About -->
    <div class="tab-wrapper">
      <ul id="tab-menu">
        <li class="selected"><img src="style/images/icon-art.png" alt="" /> Notices</li>
        <li><img src="style/images/time.png" alt="" /> Time Table</li>
        
		 <li><img src="style/images/result.png" alt="" /> Logout</li>
      </ul>
      <div class="tab-content">
        <div class="tab show">
          
          <h3>Notices</h3>
          <p> 
			
				 <?php
		  include ("connection.php");
		  
		  $query="SELECT notice, details, date FROM adminnotice";
		  $res=mysql_query($query) or die("Query failed...".mysql_error());
		  echo "<table><tr><th>NOTICE</th><th>DETAILS</th><th>DATE</th></tr>";
		  while($row=mysql_fetch_array($res))
			{
				
				echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td></tr>";
			
			}
		  echo "</table>";
		  ?>
			</div>
		  </p>
        <div class="tab">
          <h3>Time Table</h3>
          <p> 
<?php
		
		include "connection.php";
		$query2="SELECT Branch,Year from studentlogin where studentid='".$_SESSION['logged_in']."'";
		$res2=mysql_query($query2) or die("Query failed...".mysql_error());
		$branchsel='';
		$yrsel=0;
		while($row2=mysql_fetch_array($res2))
		{	
			$branchsel=$row2[0];
			$yrsel=$row2[1];
		}
		$val = mysql_query("select 1 from tt_".$branchsel."_".$yrsel);

		if($val !== FALSE)
		{
		$query="SELECT * from tt_".$branchsel."_".$yrsel;
		 $res=mysql_query($query) or die("Query failed...".mysql_error());
		  echo "<table><tr>
					<td>Day/Time</td>
					<td>8:00 to 9:00</td>
					<td>9:00 to 10:00</td>
					<td>10:00 to 11:00</td>
					<td>11:00 to 12:00</td>
					<td>1:00 to 2:00</td>
					<td>2:00 to 3:00</td>
				</tr>";
		  while($row=mysql_fetch_array($res))
			{
				echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td></tr>";
			
			}
		}
		  echo "</table>";
		  ?>		
		  </p>
        </div>
        
       
		 
      </div>
    </div>
    <div class="clear"></div>
    <!-- End About --> 
    
  </div>
  
  <!-- End Wrapper -->
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->
<div id="footer-wrapper">
  <div id="footer">
    <div id="footer-content"> 
      
      <!-- Begin Copyright -->
      <div id="copyright">
        <p>© Copyright 2011 Delphic | Creative Portfolio Template</p>
      </div>
      <!-- End Copyright --> 
      
      <!-- Begin Social Icons -->
      <div id="socials">
        <ul>
          <li><a href="#"><img src="style/images/icon-rss.png" alt="" /></a></li>
          <li><a href="#"><img src="style/images/icon-twitter.png" alt="" /></a></li>
          <li><a href="#"><img src="style/images/icon-dribble.png" alt="" /></a></li>
          <li><a href="#"><img src="style/images/icon-tumblr.png" alt="" /></a></li>
          <li><a href="#"><img src="style/images/icon-flickr.png" alt="" /></a></li>
          <li><a href="#"><img src="style/images/icon-facebook.png" alt="" /></a></li>
        </ul>
      </div>
      <!-- End Social Icons --> 
      
    </div>
  </div>
</div>
<!-- End Footer --> 

<script type="text/javascript">

$(document).ready(function() {	
  //Get all the LI from the #tabMenu UL
  $('#tab-menu > li').click(function(){
    //remove the selected class from all LI    
    $('#tab-menu > li').removeClass('selected');
    //Reassign the LI
    $(this).addClass('selected');
    //Hide all the DIV in .tab-content
    $('.tab-content div.tab').slideUp('slow');
    //Look for the right DIV in boxBody according to the Navigation UL index, therefore, the arrangement is very important.
    $('.tab-content div.tab:eq(' + $('#tab-menu > li').index(this) + ')').slideDown('slow');
  }).mouseover(function() {
    //Add and remove class, Personally I dont think this is the right way to do it, anyone please suggest    
    $(this).addClass('mouseover');
    $(this).removeClass('mouseout');   
  }).mouseout(function() {
    //Add and remove class
    $(this).addClass('mouseout');
    $(this).removeClass('mouseover');    
  });
});


$(function() {
            var offset = $("#tab-menu").offset();
            var topPadding = 15;
            $(window).scroll(function() {
                if ($(window).scrollTop() > offset.top) {
                    $("#tab-menu").stop().animate({
                        marginTop: $(window).scrollTop() - offset.top + topPadding
                    });
                } else {
                    $("#tab-menu").stop().animate({
                        marginTop: 0
                    });
                };
            });
        });
  

</script>
</body>
</html>
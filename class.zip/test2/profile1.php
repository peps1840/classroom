
		
	   <?php
	   
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
			
			$name=$_POST['sname'];
			$qua=$_POST['qua'];
			$add=$_POST['add'];
			$sa=$_POST['sa'];
			$aadhar=$_POST['aadhar'];
			$pan=$_POST['pan'];
			
			
			$query2="INSERT INTO profile values('".$name."','".$qua."','".$add."','".$sa."','".$aadhar."','".$pan."')";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			if($res2==1)
			{
				echo "successfully uploaded";
				header('location:profile.php');
			}
			
			
		 
		  ?>
	   
	    
	
	
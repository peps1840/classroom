<?php

include("connection.php");
echo "hi";
if(isset($_POST['submit']))
{	echo "hi";
	$id=$_POST["userName"];
	$des=$_POST["role"];


	
if($des=="hod")
	{
	
		$query="SELECT * FROM branch where id='".$id."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['hodid'];
			header('location:hod.php');
			
			}
		}
		
		
	}
	
	else if($des=="faculty")
	{
	
		$query="SELECT * FROM fac where id='".$id."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['facultyid'];
			header('location:faculty.php');
			}
		}
		
		
	}
	
	else if($des=="student")
	{
	
		$query="SELECT * FROM studentc where id='".$id."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['studentid'];
			header('location:student.php');
			}
		}
		
		
	}
	
	
		

	
	else if($des=="library")
	{
	
		$query="SELECT * FROM librarylogin where libid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['libid'];
			header('location:lib.php');
			}
		}
		
		
	}
	
	else if($des=="parent")
	{
	
		$query="SELECT * FROM parentlogin where parid='".$id."'AND password='".$pass."'";
		$res=mysql_query($query) or die("Query failed...".mysql_error());
		if(mysql_num_rows($res)==1)
		{while($row=mysql_fetch_array($res))
		
			{echo "Welcome ".$row['parid'];
			header('location:parents.php');
			}
		}
		
		
	}
	else
		echo "Invalid username or password input.Please try again...";
}
?>
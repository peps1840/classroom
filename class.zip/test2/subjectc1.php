
	   <?php
	   
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');

		  include ("connection.php");
			
			$sub=$_POST['subject'];
			
			$fac=$_POST['faculty'];
			$query="INSERT INTO subjectc values('".$sub."','".$fac."')";
			$res=mysql_query($query) or die("Query failed...".mysql_error());
			if($res==1)
			{
				echo "successfully uploaded";
				header('location:subjectc.php');
			}
			
			
		 
		  ?>
	   
	    
	
	
<?php
session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
?><!DOCTYPE HTML>
<html lang="en-US">
<head>
<meta charset="UTF-8">
<title>Delphic | Creative Portfolio Template</title>
<link rel="stylesheet" type="text/css" href="style.css" media="all" />
<link rel="stylesheet" media="all" href="style/css/prettyPhoto.css" />
<link rel="stylesheet" media="all" href="style/type/folks.css" />
<!--[if IE 7]>
<link rel="stylesheet" type="text/css" href="style/css/ie7.css" media="all" />
<![endif]-->
<script type="text/javascript" src="style/js/jquery-1.5.min.js"></script>
<script type="text/javascript" src="style/js/ddsmoothmenu.js"></script>
<script type="text/javascript" src="style/js/quicksand.js"></script>
<script type="text/javascript" src="style/js/portfolio.js"></script>
<script type="text/javascript" src="style/js/scripts.js"></script>
<script type="text/javascript" src="style/js/jquery.prettyPhoto.js"></script>
</head>
<body>
<div id="container"> 
  <!-- Begin Header Wrapper -->
  <div id="page-top">
    <div id="header-wrapper"> 
      <!-- Begin Header -->
      <div id="header">
        
        <!-- Logo --> 
        <!-- Begin Menu -->
        <div id="menu-wrapper">
          <div id="smoothmenu1" class="ddsmoothmenu">
            <ul>
              <li><a href="index.html" class="selected">COLLEGE MANAGEMENT SYSTEM</a>
               
              </li>
             
        <!-- End Menu -->
      </div>
      <!-- End Header --> 
    </div>
  </div>
  <!-- End Header Wrapper --> 
   <!-- Begin Slider -->
 
  <!-- End Slider -->
  
  <!-- Begin Wrapper -->
  <div id="wrapper">
    <div id="portfolio"> 
	<br> <br> <br> <br>
	<br> <br>
      <!-- Begin Portfolio Navigation -->
      
      <!-- End Portfolio Navigation --> 
      
      <!-- Begin Portfolio Elements -->
      <ul id="gallery" class="grid">
        
        <!-- Begin Image 1 -->
       
       <h1><center>TIME TABLE</h1>
	   
		
		
		
		
		<?php
		include "connection.php";
		$yrsel=$_POST['yrsel'];
		$branchsel=$_POST['branchsel'];
		$val = mysql_query("select 1 from tt_".$branchsel."_".$yrsel);

		if($val !== FALSE)
		{
		$query="SELECT * from tt_".$branchsel."_".$yrsel;
		 $res=mysql_query($query) or die("Query failed...".mysql_error());
		  echo "<table><tr>
					<td>Day/Time</td>
					<td>8:00 to 9:00</td>
					<td>9:00 to 10:00</td>
					<td>10:00 to 11:00</td>
					<td>11:00 to 12:00</td>
					<td>1:00 to 2:00</td>
					<td>2:00 to 3:00</td>
				</tr>";
		  while($row=mysql_fetch_array($res))
			{
				echo "<tr><td>".$row[0]."</td><td>".$row[1]."</td><td>".$row[2]."</td><td>".$row[3]."</td><td>".$row[4]."</td><td>".$row[5]."</td><td>".$row[6]."</td></tr>";
			
			}
		  echo "</table>";
		}  
		echo '<input type="submit" name="add" value="upload"  onClick="show()";>
		<div id="add" style="display:none;">
	  <form name="notice" action="tt1.php" method="post">
	  <input type="text" name="branchsel" value="'.$branchsel.'">
	  <input type="number" name="yrsel" value="'.$yrsel.'">
			<table>
			
			<tr>
					<td><label>Time</label></td>
					<td>8:00 to 9:00</td>
					<td>9:00 to 10:00</td>
					<td>10:00 to 11:00</td>
					<td>11:00 to 12:00</td>
					<td>1:00 to 2:00</td>
					<td>2:00 to 3:00</td>
				</tr>
				
				
				<tr>
					<td><label>monday</label></td>
					<td><input type="text" name="msubject1" style="width:50px;"></td>
					<td><input type="text" name="msubject2" style="width:50px;"></td>
					<td><input type="text" name="msubject3" style="width:50px;"></td>
					<td><input type="text" name="msubject4" style="width:50px;"></td>
					<td><input type="text" name="msubject5" style="width:50px;"></td>
					<td><input type="text" name="msubject6" style="width:50px;"></td>
				</tr>
				<tr>
					<td><label>tuesday</label></td>
					<td><input type="text" name="tsubject1" style="width:50px;"></td>
					<td><input type="text" name="tsubject2" style="width:50px;"></td>
					<td><input type="text" name="tsubject3" style="width:50px;"></td>
					<td><input type="text" name="tsubject4" style="width:50px;"></td>
					<td><input type="text" name="tsubject5" style="width:50px;"></td>
					<td><input type="text" name="tsubject6" style="width:50px;"></td>
				</tr>
				<tr>
					<td><label>wednesday</label></td>
					<td><input type="text" name="wsubject1" style="width:50px;"></td>
					<td><input type="text" name="wsubject2" style="width:50px;"></td>
					<td><input type="text" name="wsubject3" style="width:50px;"></td>
					<td><input type="text" name="wsubject4" style="width:50px;"></td>
					<td><input type="text" name="wsubject5" style="width:50px;"></td>
					<td><input type="text" name="wsubject6" style="width:50px;"></td>
				</tr>
				<tr>
					<td><label>thursday</label></td>
					<td><input type="text" name="thsubject1" style="width:50px;"></td>
					<td><input type="text" name="thsubject2" style="width:50px;"></td>
					<td><input type="text" name="thsubject3" style="width:50px;"></td>
					<td><input type="text" name="thsubject4" style="width:50px;"></td>
					<td><input type="text" name="thsubject5" style="width:50px;"></td>
					<td><input type="text" name="thsubject6" style="width:50px;"></td>
				</tr>
				<tr>
					<td><label>friday</label></td>
					<td><input type="text" name="fsubject1" style="width:50px;"></td>
					<td><input type="text" name="fsubject2" style="width:50px;"></td>
					<td><input type="text" name="fsubject3" style="width:50px;"></td>
					<td><input type="text" name="fsubject4" style="width:50px;"></td>
					<td><input type="text" name="fsubject5" style="width:50px;"></td>
					<td><input type="text" name="fsubject6" style="width:50px;"></td>
				</tr>
				<tr>
					<td><label>saturday</label></td>
					<td><input type="text" name="ssubject1" style="width:50px;"></td>
					<td><input type="text" name="ssubject2" style="width:50px;"></td>
					<td><input type="text" name="ssubject3" style="width:50px;"></td>
					<td><input type="text" name="ssubject4" style="width:50px;"></td>
					<td><input type="text" name="ssubject5" style="width:50px;"></td>
					<td><input type="text" name="ssubject6" style="width:50px;"></td>
				</tr>
				
			</table>
			
			<input type="submit" value="upload" name="tt">
		</form>
	</div>';
	?>
	   
	   
		</center>

        
      </ul>
      <!-- End Portfolio Elements --> 
      
    </div>
  </div>
  
  <!-- End Wrapper -->
  <div class="clearfix"></div>
  <div class="push"></div>
</div>

<!-- Begin Footer -->


<!-- End Footer --> 
<script type="text/javascript">
$(document).ready(function(){
			$("#gallery a[rel^='prettyPhoto']").prettyPhoto({theme:'light_square',autoplay_slideshow: false});
			
			$("ul.grid img").hide()
			$("ul.grid img").each(function(i) {
			  $(this).delay(i * 200).fadeIn();
			});
			
});

function view()
{
	
	document.getElementById("view").style="display:inline;";
}

function show()
{
	
	document.getElementById("add").style="display:inline;";
}


</script>
</body>
</html>
<?php

session_start();
if($_SESSION['logged_in']=="")
	header('location:index.html');
include ("connection.php");
			$branchsel=$_POST['branchsel'];
			$yearsel=$_POST['yrsel'];
			echo $yearsel;
			$msubject1=$_POST['msubject1'];
			$msubject2=$_POST['msubject2'];
			$msubject3=$_POST['msubject3'];
			$msubject4=$_POST['msubject4'];
			$msubject5=$_POST['msubject5'];
			$msubject6=$_POST['msubject6'];
			
			$tsubject1=$_POST['tsubject1'];
			$tsubject2=$_POST['tsubject2'];
			$tsubject3=$_POST['tsubject3'];
			$tsubject4=$_POST['tsubject4'];
			$tsubject5=$_POST['tsubject5'];
			$tsubject6=$_POST['tsubject6'];
			
			$wsubject1=$_POST['wsubject1'];
			$wsubject2=$_POST['wsubject2'];
			$wsubject3=$_POST['wsubject3'];
			$wsubject4=$_POST['wsubject4'];
			$wsubject5=$_POST['wsubject5'];
			$wsubject6=$_POST['wsubject6'];
			
			$thsubject1=$_POST['thsubject1'];
			$thsubject2=$_POST['thsubject2'];
			$thsubject3=$_POST['thsubject3'];
			$thsubject4=$_POST['thsubject4'];
			$thsubject5=$_POST['thsubject5'];
			$thsubject6=$_POST['thsubject6'];
			
			$fsubject1=$_POST['fsubject1'];
			$fsubject2=$_POST['fsubject2'];
			$fsubject3=$_POST['fsubject3'];
			$fsubject4=$_POST['fsubject4'];
			$fsubject5=$_POST['fsubject5'];
			$fsubject6=$_POST['fsubject6'];
			
			$ssubject1=$_POST['ssubject1'];
			$ssubject2=$_POST['ssubject2'];
			$ssubject3=$_POST['ssubject3'];
			$ssubject4=$_POST['ssubject4'];
			$ssubject5=$_POST['ssubject5'];
			$ssubject6=$_POST['ssubject6'];
			
			
			
			$val = mysql_query("select 1 from tt_".$branchsel."_".$yearsel);

		if($val !== FALSE)
		{
			$query="DROP TABLE tt_".$branchsel."_".$yearsel;
			$res=mysql_query($query) or die("Query failed...".mysql_error());
		}
			
			
			$query2="CREATE TABLE tt_".$branchsel."_".$yearsel." (day varchar(30),tsub1 varchar(30),tsub2 varchar(30),tsub3 varchar(30),tsub4 varchar(30),tsub5 varchar(30),tsub6 varchar(30))";
			$res2=mysql_query($query2) or die("Query failed...".mysql_error());
			
			$query3="INSERT INTO tt_".$branchsel."_".$yearsel." VALUES('Monday','".$msubject1."','".$msubject2."','".$msubject3."','".$msubject4."','".$msubject5."','".$msubject6."')
			,('Tuesday','".$tsubject1."','".$tsubject2."','".$tsubject3."','".$tsubject4."','".$tsubject5."','".$tsubject6."')
			,('Wednesday','".$wsubject1."','".$wsubject2."','".$wsubject3."','".$wsubject4."','".$wsubject5."','".$wsubject6."')
			,('Thursday','".$thsubject1."','".$thsubject2."','".$thsubject3."','".$thsubject4."','".$thsubject5."','".$thsubject6."')
			,('Friday','".$fsubject1."','".$fsubject2."','".$fsubject3."','".$fsubject4."','".$fsubject5."','".$fsubject6."')
			,('Saturday','".$ssubject1."','".$ssubject2."','".$ssubject3."','".$ssubject4."','".$ssubject5."','".$ssubject6."')";
			
			$res3=mysql_query($query3) or die("Query failed...".mysql_error());
			if($res3==1)
			{
				header('location:timetable.php');
			}
		 
		  ?>
	   
	    
	
	